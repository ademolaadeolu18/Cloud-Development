1) Created the S3 bucket-“for-stat-website”
2) Uploaded relevant files and folders for the website
3) Chose the option to enable the bucket host the website
4) Secured the bucket via IAM by Updating the bucket policy
5) Distributed the website via CloudFront

Domain Name: d17uwfv82kejz4.cloudfront.net
URL http://d17uwfv82kejz4.cloudfront.net/index.html